/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author ruben
 */
public class BGeometry {

    private String id;
    private String tipo;
    private String Cordenadas;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCordenadas() {
        return Cordenadas;
    }

    public void setCordenadas(String Cordenadas) {
        this.Cordenadas = Cordenadas;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    

}
